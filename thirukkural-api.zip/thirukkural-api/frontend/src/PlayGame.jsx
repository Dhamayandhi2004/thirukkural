import React, { useState } from 'react';

const PlayGame = () => {
    const [targetNumber, setTargetNumber] = useState(Math.floor(Math.random() * 100) + 1);
    const [guess, setGuess] = useState('');
    const [message, setMessage] = useState('');

    const handleGuessChange = (e) => {
        setGuess(e.target.value);
    };

    const handleGuessSubmit = () => {
        const guessNumber = parseInt(guess, 10);
        if (isNaN(guessNumber)) {
            setMessage('Please enter a valid number.');
        } else if (guessNumber < targetNumber) {
            setMessage('Too low! Try again.');
        } else if (guessNumber > targetNumber) {
            setMessage('Too high! Try again.');
        } else {
            setMessage('Congratulations! You guessed the right number.');
        }
    };

    const handleResetGame = () => {
        setTargetNumber(Math.floor(Math.random() * 100) + 1);
        setGuess('');
        setMessage('');
    };

    return (
        <div className="container mt-5">
            <h2>Play Game</h2>
            <p>Guess the number between 1 and 100:</p>
            <input
                type="text"
                value={guess}
                onChange={handleGuessChange}
                className="form-control mb-2"
                placeholder="Enter your guess"
            />
            <button onClick={handleGuessSubmit} className="btn btn-primary mb-2">
                Submit Guess
            </button>
            <button onClick={handleResetGame} className="btn btn-secondary mb-2">
                Reset Game
            </button>
            {message && <p>{message}</p>}
        </div>
    );
};

export default PlayGame;
