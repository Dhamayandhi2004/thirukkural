import { useState } from 'react';
import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import Thirukkural from './Thirukkural';
import CreateThirukkural from './Createthirukkural.jsx';
import UpdateThirukkural from './Updatethirukkural.jsx';
import LoginPage from './LoginPage.jsx';
import PlayGame from './PlayGame';
import PDFConverter from './PDFConverter'; 


function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <BrowserRouter>
        <Routes>
        <Route  path='/' element={<LoginPage/>}/>
        <Route path='/thirukkural' element={<Thirukkural />} />
        <Route path='/create' element={<CreateThirukkural />} />
        <Route path='/update/:id' element={<UpdateThirukkural />} />
        <Route path='/playgame' element={<PlayGame/>} />
        <Route path='/pdfconverter' element={<PDFConverter />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;