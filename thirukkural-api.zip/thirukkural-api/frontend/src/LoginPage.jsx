// LoginPage.jsx
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Login.css';

const LoginPage = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const handleLogin = () => {
        // Perform authentication logic here
        if (username === 'admin' && password === 'password') {
            // Redirect to Thirukkural page after successful login
            alert('Login successful! Redirecting...');
            // You can use window.location.href or Link component for navigation
        } else {
            alert('Invalid username or password');
        }
    };

    return (
        <div className="login-page">
            <div className="background-image"></div>
            <div className="login-container">
                <div className="login-form">
                    <h2>Login</h2>
                    <div className="form-group">
                        <input 
                            type="text" 
                            placeholder="Username" 
                            value={username} 
                            onChange={(e) => setUsername(e.target.value)} 
                        />
                    </div>
                    <div className="form-group">
                        <input 
                            type="password" 
                            placeholder="Password" 
                            value={password} 
                            onChange={(e) => setPassword(e.target.value)} 
                        />
                    </div>
                    <Link to="/thirukkural" className="btn btn-primary" onClick={handleLogin}>Login</Link>
                </div>
            </div>
        </div>
    );
};

export default LoginPage;
