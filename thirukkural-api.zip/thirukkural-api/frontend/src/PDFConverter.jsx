// PDFConverter.jsx
import React, { useState } from 'react';
import { jsPDF } from 'jspdf';

const PDFConverter = () => {
    const [inputText, setInputText] = useState('');

    const handleConvertToPDF = () => {
        const doc = new jsPDF();
        doc.text(inputText, 10, 10);
        doc.save('output.pdf');
    };

    return (
        <div className="container mt-5">
            <div className="row">
                <div className="col-md-12">
                    <input 
                        type="text" 
                        className="form-control mb-2" 
                        placeholder="Enter text to convert to PDF" 
                        value={inputText}
                        onChange={(e) => setInputText(e.target.value)} 
                    />
                    <button className="btn btn-primary" onClick={handleConvertToPDF}>Generate PDF</button>
                </div>
            </div>
        </div>
    );
};

export default PDFConverter;
